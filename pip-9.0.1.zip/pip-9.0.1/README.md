如何安装:

cd到本目录, 执行名命令 sudo python setup.py install
